package com.example.animsplashdemo;

public class TvShow {
    String name, createdBy, story;
    int imanges;
    Boolean isSelected = false;
    float rating;
}
