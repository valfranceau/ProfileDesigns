package com.example.animsplashdemo;


public interface TvShowListener {
    void onTvShowAction(Boolean isSelected);
}
